package com.github.yjcpa1.smart_mirror.activity;

/**
 * Created by LeeJunHo on 2017-08-06.
 */

public class EventData {

    private long calendarId;
    private String title;
    private String date;

    public  EventData(Long id, String title,String date){
        calendarId=id;
        this.title=title;
        this.date=date;
    }

    public String getTitle(){
        return title;
    }

    public void setTitle(String title){this.title=title;}

    public String getDate(){
        return date;
    }

    public void setDate(String date){this.date=date;}

    public Long getCalendarId(){
        return calendarId;
    }

    public void setCalendarId(long id){calendarId=id;}
}
