package com.github.yjcpa1.smart_mirror.activity;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.github.yjcpa1.smart_mirror.R;
import com.github.yjcpa1.smart_mirror.service.CalendarService;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    ListView listView = null;
    IdList idList;
    ArrayList<CalendarName> calendarNames = new ArrayList<CalendarName>();
    Long dataid = null;
    Intent calendarintent;

    String FileName = "Calendar_id";
    File file;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Intent intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");//안드로이드 설정쪽으로 넘어가는 부분
        startActivity(intent);

//        ------------------------------------------------------------------------------------------

        final String[] calendarName = new String[]{};
        String displayName = null;
        idList = new IdList(MainActivity.this, calendarNames);
        listView = (ListView) findViewById(R.id.calendar_listview);
        listView.setAdapter(idList);
        final TextView asyncId=(TextView) findViewById(R.id.textView7);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() { // 클릭했을때 해당 계정의 일정데이터 저장.

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                serviceList();
                dataid = idList.getItemId(position);
                String str= (String) asyncId.getText();
                int check = 0;
                int i;

                FileReader fr = null;
                try {
                    if(str.contains("@")) {
                        // open file.
                        file = new File(getFilesDir(), FileName);
                        fr = new FileReader(file) ;
                        // read file.
                        while ((i = fr.read()) != -1) {
                            check= i ;
                        }
                        fr.close() ;
                        Log.i("check값", String.valueOf(check));
                        if (dataid != check) //  다른 아이디면
                        {
                            Log.i("나와라","다른아이디일떄");
                            stopService(calendarintent);
                            file = new File(getFilesDir(), FileName) ;
                            FileOutputStream os = openFileOutput(FileName, MODE_PRIVATE);
                            os.write(Integer.parseInt(String.valueOf(dataid)));
                            Log.i("저장됨",""+dataid);
                            os.close();
                            asyncId.setText("자동 동기화 계정 :"+ idList.getItem(position));

                            calendarintent = new Intent(MainActivity.this, CalendarService.class);
                            startService(calendarintent);
                            Log.i("아이디",""+id);

                            return;
                        }

                        if(dataid == check) // 이미 등록된 아이디면
                        {
                            Log.i("나와라","같은아이디일때ㅇㅇ");
                            stopService(calendarintent);
                            Log.i("서비스 삭제됨","서비스삭제됨ㅇㅋ");
                            asyncId.setText("자동 동기화 계정 :");

                            return;
                        }

                    }

                    file = new File(getFilesDir(), FileName) ;
                    FileOutputStream os = openFileOutput(FileName, MODE_PRIVATE);
                    os.write(Integer.parseInt(String.valueOf(dataid)));
                    Log.i("저장됨",""+dataid);
                    os.close();
                    asyncId.setText("자동 동기화 계정 :"+ idList.getItem(position));

                    calendarintent = new Intent(MainActivity.this, CalendarService.class);
                    startService(calendarintent);
                    Log.i("아이디",""+id);

                }catch (FileNotFoundException e){
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });

        String[] projection =
                new String[]{
                        CalendarContract.Calendars._ID,
                        CalendarContract.Calendars.NAME,
                        CalendarContract.Calendars.ACCOUNT_NAME,
                        CalendarContract.Calendars.ACCOUNT_TYPE,
                        CalendarContract.Calendars.OWNER_ACCOUNT
                };

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        Cursor calCursor =
                getContentResolver().
                        query(CalendarContract.Calendars.CONTENT_URI,
                                projection,
                                CalendarContract.Calendars.VISIBLE + " = 1",
                                null,
                                CalendarContract.Calendars._ID + " ASC");
        if (calCursor.moveToFirst()) {
            do {
                long id = calCursor.getLong(0);
                displayName = calCursor.getString(1);
                String cID = calCursor.getString(calCursor.getColumnIndex(CalendarContract.Calendars._ID));
                String cName = calCursor.getString(calCursor.getColumnIndex(CalendarContract.Calendars.NAME));
                String cAC = calCursor.getString(calCursor.getColumnIndex(CalendarContract.Calendars.ACCOUNT_NAME));
                String cWA = calCursor.getString(calCursor.getColumnIndex(CalendarContract.Calendars.OWNER_ACCOUNT));

                CalendarName options = new CalendarName(displayName, Integer.parseInt(cID));
                if (options.getName().contains("@")) {
                    calendarNames.add(options);
                }
            } while (calCursor.moveToNext());
        }
    }//onCreate
    public void serviceList(){
  /*서비스 리스트*/
        ActivityManager am = (ActivityManager)getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> rs = am.getRunningServices(1000);

        for(int i=0; i<rs.size(); i++){
            ActivityManager.RunningServiceInfo rsi = rs.get(i);
            Log.d("run service","Package Name : " + rsi.service.getPackageName());
            Log.d("run service","Class Name : " + rsi.service.getClassName());
        }
    }
}
