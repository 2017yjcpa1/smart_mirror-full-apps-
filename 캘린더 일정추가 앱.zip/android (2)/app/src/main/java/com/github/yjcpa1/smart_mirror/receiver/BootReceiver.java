package com.github.yjcpa1.smart_mirror.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.github.yjcpa1.smart_mirror.activity.MainActivity;
import com.github.yjcpa1.smart_mirror.service.CalendarService;

/**
 * Created by HAN on 2017-08-13.
 */

public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        if (intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)) {
            Intent i = new Intent(context, CalendarService.class);
            context.startService(i);
        }
    }
}
