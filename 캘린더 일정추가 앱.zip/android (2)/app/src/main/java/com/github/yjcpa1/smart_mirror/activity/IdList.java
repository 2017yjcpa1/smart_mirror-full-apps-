package com.github.yjcpa1.smart_mirror.activity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.github.yjcpa1.smart_mirror.R;

import java.util.ArrayList;

public class IdList extends BaseAdapter {
    private LayoutInflater mInflater;
    private ArrayList<CalendarName> itemes=null;
    Context c;

    public IdList(Context c , ArrayList<CalendarName> itemes) {
        this.c = c;
        this.itemes=itemes;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return itemes.size();
    }

    @Override
    public Object getItem(int position) {
        return itemes.get(position).getName();
    }

    @Override
    public long getItemId(int position) {
        return itemes.get(position).getNum();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TextView textView = null;

        if(convertView == null){
            convertView = mInflater.inflate(R.layout.item1, parent, false);
            textView = (TextView)convertView.findViewById(R.id.text);
            convertView.setTag(textView);
        }
        else{
            textView = (TextView)convertView.getTag();
        }
        textView.setText(itemes.get(position).getName());
        return convertView;
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
    }
}
