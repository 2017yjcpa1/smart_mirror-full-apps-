package com.github.yjcpa1.smart_mirror.service;

import android.Manifest;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.IBinder;
import android.os.StrictMode;
import android.provider.CalendarContract;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import com.github.yjcpa1.smart_mirror.activity.EventData;
import com.github.yjcpa1.smart_mirror.util.SimpleHttpClient;
import com.google.gson.Gson;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class CalendarService extends Service{
    ServiceThread thread;
    int id=0;
    ArrayList<EventData> eventDatas=new ArrayList<>();
    String[] proj;
    String FileName = "Calendar_id";

    File file;
    FileReader fr = null ;
    int data;


    public void setId(int id){
        this.id=id;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            // open file.
            file = new File(getFilesDir(), FileName);
            fr = new FileReader(file) ;
            // read file.
            while ((data = fr.read()) != -1) {
                id = data ;
                Log.i("아이디값불러오기",""+id);
            }
            fr.close() ;
        } catch (Exception e) {
            e.printStackTrace() ;
        }
        thread = new ServiceThread();
        thread.start();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        thread.interrupt();
    }

    class ServiceThread extends Thread{
        @Override
        public void run() {
            try {
                while((!Thread.currentThread().isInterrupted())) {
                    searchData(id);
                    Log.i("달력정보전송", "" + id);
                    sleep(10000);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void searchData(long id) {
        ArrayList<String> title_array=new ArrayList<>();
        ArrayList<String> date_array=new ArrayList<>();

        proj =
                new String[]{
                        CalendarContract.Events._ID,
                        CalendarContract.Events.CALENDAR_ID,
                        CalendarContract.Events.DTSTART,
                        CalendarContract.Events.DTEND,
                        CalendarContract.Events.EVENT_COLOR,
                        CalendarContract.Events.TITLE};
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Cursor cursor =
                getContentResolver().
                        query(
                                CalendarContract.Events.CONTENT_URI,
                                proj,
                                CalendarContract.Events.CALENDAR_ID + " = "+id,
                                null,
                                null);

        if (cursor.moveToFirst()) {

            String title=cursor.getString(cursor.getColumnIndex(CalendarContract.Events.TITLE));
            String time=cursor.getString(cursor.getColumnIndex(CalendarContract.Events.DTSTART));
            String num=cursor.getString(cursor.getColumnIndex(CalendarContract.Events.CALENDAR_ID));
            String e=cursor.getString(cursor.getColumnIndex(CalendarContract.Events._ID));

            String date = new java.text.SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new java.util.Date (Long.parseLong(time)));

            Log.i("제목",title);
            Log.i("시간", date);
            eventDatas.add(new EventData(id,title,date));


            while(cursor.moveToNext()){
                title=cursor.getString(cursor.getColumnIndex(CalendarContract.Events.TITLE));
                time=cursor.getString(cursor.getColumnIndex(CalendarContract.Events.DTSTART));
                date = new java.text.SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new java.util.Date (Long.parseLong(time)));
                Log.i("제목",title);
                Log.i("시간",date);
                eventDatas.add(new EventData(id,title,date));
            }
        }

        new AsyncTask<String, Void, String>() {

            @Override
            protected String doInBackground(String[] params) {
                try {
                    SimpleHttpClient.post("http://192.168.0.2/smart_mirror/web/php/calendar_store.php/", "message", new Gson().toJson(eventDatas));
                    eventDatas.clear();
                }
                catch(IOException e) {
                    e.printStackTrace();
                }

                return null;
            }

        }.execute();
    }
}
